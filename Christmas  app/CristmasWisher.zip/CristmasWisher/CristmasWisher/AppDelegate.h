//
//  AppDelegate.h
//  CristmasWisher
//
//  Created by Bunti Nizama on 12/13/13.
//  Copyright (c) 2013 Bunti Nizama. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
