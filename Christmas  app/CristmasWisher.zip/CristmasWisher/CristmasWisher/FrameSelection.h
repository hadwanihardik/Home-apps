//
//  FrameSelection.h
//  CristmasWisher
//
//  Created by Hardik Hadwani on 15/12/13.
//  Copyright (c) 2013 Bunti Nizama. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PreviewViewController.h"

@interface FrameSelection : UIViewController<UIScrollViewDelegate>
{
    PreviewViewController *viewPreview;
    IBOutlet UIScrollView *scrlviewFrames;
    IBOutlet UIScrollView *scrlThoughts;

    int selected;
    int selectedthought;

    IBOutlet UIImageView *mainimageLeft;
    IBOutlet UIImageView *mainimageRight;
    IBOutlet UIView *frameSelection;



}
@property (nonatomic,retain) IBOutlet UIImageView *mainimage;
@property (nonatomic,retain)  UIImage *selectedImage;
-(IBAction)btnNext:(id)sender;

@end
