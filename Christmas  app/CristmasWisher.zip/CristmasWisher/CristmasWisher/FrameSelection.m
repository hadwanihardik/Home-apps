//
//  FrameSelection.m
//  CristmasWisher
//
//  Created by Hardik Hadwani on 15/12/13.
//  Copyright (c) 2013 Bunti Nizama. All rights reserved.
//

#import "FrameSelection.h"
#import "PreviewViewController.h"
@interface FrameSelection ()

@end

@implementation FrameSelection
@synthesize selectedImage,mainimage;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    mainimage.image=self.selectedImage;
    mainimageLeft.image=self.selectedImage;
    mainimageRight.image=self.selectedImage;
    UISwipeGestureRecognizer *swipeleft=[[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(prevframe:)];
    swipeleft.direction=UISwipeGestureRecognizerDirectionLeft;
    [frameSelection addGestureRecognizer:swipeleft];
   
    UISwipeGestureRecognizer *swipeRight=[[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(nextframe:)];
    swipeRight.direction=UISwipeGestureRecognizerDirectionRight;
    [frameSelection addGestureRecognizer:swipeRight];
    
    int x=0,y=0;    for (int i=0;i<=9;i++)
    {
        UIImage *im=[UIImage imageNamed:[NSString stringWithFormat:@"frm%d.png",i]];
        UIImageView *imv=[[UIImageView alloc] initWithFrame:CGRectMake(x,y,124,184)];
        imv.image=im;
        imv.tag=100+i;
        [scrlviewFrames addSubview:imv];
        x=x+124;
    }
    scrlviewFrames.contentSize=CGSizeMake(x,184);
    [scrlviewFrames setContentOffset:CGPointMake(248,0)];

    x=0,y=0;
    for (int i=0;i<=9;i++)
    {
        UIImage *im=[UIImage imageNamed:[NSString stringWithFormat:@"frm%d.png",i]];
        UIImageView *imv=[[UIImageView alloc] initWithFrame:CGRectMake(x,y,320,100)];
        imv.image=im;
        imv.tag=200+i;
        [scrlThoughts addSubview:imv];
        x=x+320;
    }
    scrlThoughts.contentSize=CGSizeMake(x,100);

    // Do any additional setup after loading the view from its nib.
}
- (void)scrollViewDidScroll:(UIScrollView *)scrollView// called when setContentOffset/scrollRectVisible:animated: finishes. not called if not animating
{
    CGFloat pagewidth =scrollView.frame.size.width;
    if (scrollView.tag==1)
    {
        selected = floor((scrollView.contentOffset.x - pagewidth / 2) / pagewidth) + 1;
        
    }
    else
    {
        selectedthought = floor((scrollView.contentOffset.x - pagewidth / 2) / pagewidth) + 1;
        
    }
    NSLog(@"selected %d",selected);
    
}
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    NSLog(@"selected end");
    if (scrollView.tag==1)
    {
        [scrlviewFrames setContentOffset:CGPointMake(selected*124,0)];

    }
    else
    {
        [scrlThoughts setContentOffset:CGPointMake(selectedthought*320,0)];

    }

}
-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    NSLog(@"selected end");
    if (scrollView.tag==1)
    {
        [scrlviewFrames setContentOffset:CGPointMake(selected*124,0)];
        
    }
    else
    {
        [scrlThoughts setContentOffset:CGPointMake(selectedthought*320,0)];
        
    }
}

-(IBAction)btnNext:(id)sender
{
    
    PreviewViewController *preview = [[PreviewViewController alloc]initWithNibName:@"PreviewViewController" bundle:Nil];
    preview.imgFrame=[UIImage imageNamed:[NSString stringWithFormat:@"frm%d.png",selected]];
    preview.imgMainImage=self.selectedImage;
    preview.imgthought=[UIImage imageNamed:[NSString stringWithFormat:@"frm%d.png",selectedthought]];
    [self.navigationController pushViewController:preview animated:YES];

}
-(IBAction)prevframe:(id)sender
{
    selected-=1;
    [UIView beginAnimations:@"next" context:Nil];
    [UIView setAnimationDuration:1];
    [scrlviewFrames setContentOffset:CGPointMake(selected*124,0)];
    [UIView commitAnimations];
}
-(IBAction)nextframe:(id)sender
{
    selected+=1;

    [UIView beginAnimations:@"next" context:Nil];
    [UIView setAnimationDuration:1];
    [scrlviewFrames setContentOffset:CGPointMake(selected*124,0)];
    [UIView commitAnimations];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
