//
//  HomeViewController.h
//  CristmasWisher
//
//  Created by Bunti Nizama on 12/13/13.
//  Copyright (c) 2013 Bunti Nizama. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PreviewViewController.h"
#import "FrameSelection.h"
@interface HomeViewController : UIViewController <UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    IBOutlet UIImageView *imgView;
    FrameSelection *frameselection;
}



-(IBAction)btnCameraTapped:(id)sender;
-(IBAction)btnGalleryTapped:(id)sender;
@end
