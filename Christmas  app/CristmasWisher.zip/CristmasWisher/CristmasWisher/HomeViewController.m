//
//  HomeViewController.m
//  CristmasWisher
//
//  Created by Bunti Nizama on 12/13/13.
//  Copyright (c) 2013 Bunti Nizama. All rights reserved.
//

#import "HomeViewController.h"

@interface HomeViewController ()

@end

@implementation HomeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    frameselection = [[FrameSelection alloc]initWithNibName:@"FrameSelection" bundle:Nil];
    
    self.navigationController.navigationBarHidden = YES;
    // Do any additional setup after loading the view from its nib.
}

-(IBAction)btnCameraTapped:(id)sender
{
    if ([UIImagePickerController isCameraDeviceAvailable: UIImagePickerControllerCameraDeviceRear]){
        UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
        imagePicker.delegate = self;
        imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
        [self presentModalViewController:imagePicker animated:YES];
    }
}

-(IBAction)btnGalleryTapped:(id)sender
{
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.delegate = self;
    imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    [self presentModalViewController:imagePicker animated:YES];

}


#pragma UIImagepickercontroller delegate methods
-(void)imagePickerController:(UIImagePickerController *)picker
	   didFinishPickingImage:(UIImage *)image
				 editingInfo:(NSDictionary *)info
{
//	imgView.image = image;
    
    frameselection.selectedImage=image;

    [self dismissModalViewControllerAnimated:YES];

    [self.navigationController pushViewController:frameselection animated:YES ];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
