//
//  PreviewViewController.h
//  CristmasWisher
//
//  Created by Bunti Nizama on 12/13/13.
//  Copyright (c) 2013 Bunti Nizama. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PreviewViewController : UIViewController
{
    IBOutlet UIImageView *imgViewMainImage;
    IBOutlet UIImageView *imgViewFrame;
    IBOutlet UIImageView *imvThought;
}

@property (nonatomic,retain) UIImage *imgMainImage;
@property (nonatomic,retain) UIImage *imgFrame;
@property (nonatomic,retain) UIImage *imgthought;

-(IBAction)btnBackTapped:(id)sender;
-(IBAction)btnStickerTapped:(id)sender;
-(IBAction)btnFontTapped:(id)sender;
-(IBAction)btnFontColorTapped:(id)sender;
-(IBAction)btnShareTapped:(id)sender;


@end
