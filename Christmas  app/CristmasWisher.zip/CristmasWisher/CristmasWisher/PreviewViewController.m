//
//  PreviewViewController.m
//  CristmasWisher
//
//  Created by Bunti Nizama on 12/13/13.
//  Copyright (c) 2013 Bunti Nizama. All rights reserved.
//

#import "PreviewViewController.h"

@interface PreviewViewController ()

@end

@implementation PreviewViewController
@synthesize imgMainImage,imgFrame,imgthought;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated
{
    imgViewMainImage.image = self.imgMainImage;
    imgViewFrame.image=self.imgFrame;
    imvThought.image=imgthought;
}

-(IBAction)btnBackTapped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)btnStickerTapped:(id)sender
{
    
}

-(IBAction)btnFontTapped:(id)sender
{
    
}

-(IBAction)btnFontColorTapped:(id)sender;
{
    
}

-(IBAction)btnShareTapped:(id)sender
{
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
