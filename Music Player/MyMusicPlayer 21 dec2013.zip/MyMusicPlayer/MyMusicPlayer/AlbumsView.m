//
//  AlbumsView.m
//  MyMusicPlayer
//
//  Created by Hardik Hadwani on 08/12/13.
//  Copyright (c) 2013 Hardik Hadwani. All rights reserved.
//

#import "AlbumsView.h"
#import "AppDelegate.h"

@interface AlbumsView ()

{
    AppDelegate *app;
}
@end

@implementation AlbumsView

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.songList.count;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        
    }
    
    MPMediaItemCollection *albumCollection=[self.songList objectAtIndex:indexPath.row];
    [[albumCollection representativeItem] valueForProperty:MPMediaItemPropertyAlbumTitle];
    cell.textLabel.text=[[albumCollection representativeItem] valueForProperty:MPMediaItemPropertyAlbumTitle];
    cell.detailTextLabel.text=[[self.songList objectAtIndex:indexPath.row] valueForProperty:MPMediaItemPropertyAlbumArtist];

    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSMutableArray* marr = [NSMutableArray array];
    MPMediaItemCollection* queue = nil;
    
    [marr addObject: [self.songList objectAtIndex:indexPath.row]];
    
    if ([marr count] == 0)
        NSLog(@"No self.songList that short!");
    else
        queue = [MPMediaItemCollection collectionWithItems:marr];
    if (queue)
    {
        app.home.musicPlayer =
        [MPMusicPlayerController applicationMusicPlayer];
        [app.home.musicPlayer setQueueWithItemCollection:queue];
        [app.home.musicPlayer play];
        app.window.rootViewController=app.navHomeView;
        
    }
    
    
    
}

-(IBAction)selectTab:(UIButton *)btn
{
    app=(AppDelegate *)[[UIApplication sharedApplication] delegate];
    switch (btn.tag)
    {
        case 101: {
            app.window.rootViewController=app.navHomeView;
            break;
        }
        case 102: {
            app.window.rootViewController=app.navPlayListView;
            break;
        }
        case 103:
        {
            app.window.rootViewController=app.navSongsView;
            break;
        }
        case 104:
        {
            app.window.rootViewController=app.navAlbumsView;
            break;
        }
            
        case 105:
        {
            app.window.rootViewController=app.navMoreView;
            break;
        }
            
            
        default:
            break;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
