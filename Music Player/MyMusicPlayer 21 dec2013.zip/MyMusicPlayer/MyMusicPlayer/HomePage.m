//
//  HomePage.m
//  MyMusicPlayer
//
//  Created by Hardik Hadwani on 07/12/13.
//  Copyright (c) 2013 Hardik Hadwani. All rights reserved.
//

#import "HomePage.h"
#import "AppDelegate.h"
@interface HomePage ()
{
    AppDelegate *app;

}
@end

@implementation HomePage

@synthesize songList,musicPlayer,imvAlbumCover,lblAlbumName,songNumber;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    app=(AppDelegate *)[[UIApplication sharedApplication] delegate];
    self.musicPlayer = [MPMusicPlayerController iPodMusicPlayer];
    [self.musicPlayer pause];
    [self registerMediaPlayerNotifications];
   
    [super viewDidLoad];
}
-(void) viewWillAppear:(BOOL)animated
{
    [self CheckPlayBackState];
   
}
-(void)CheckPlayBackState
{
    MPMusicPlaybackState playbackState = [musicPlayer playbackState];

    [NSTimer scheduledTimerWithTimeInterval:1.0/60.0 target:self selector:@selector(updatetime) userInfo:nil repeats:YES];

   
    [self updatetime];
    if (playbackState == MPMusicPlaybackStatePaused)
    {
        [self.musicPlayer pause];

        [btnPlay setImage:[UIImage imageNamed:@"Play.png"] forState:UIControlStateNormal];
    }
    else if (playbackState == MPMusicPlaybackStatePlaying)
    {
        [self.musicPlayer play];

        
        [btnPlay setImage:[UIImage imageNamed:@"Pause.png"] forState:UIControlStateNormal];
    }
    else if (playbackState == MPMusicPlaybackStateStopped)
    {
       // [self.musicPlayer stop
         ///];

        [btnPlay setImage:[UIImage imageNamed:@"Play.png"] forState:UIControlStateNormal];
    }
}
-(void)playsong:(int )songnum
{
    [btnPlay setImage:[UIImage imageNamed:@"Pause.png"] forState:UIControlStateNormal];

    
    NSMutableArray* marr = [NSMutableArray array];
    MPMediaItemCollection* queue = nil;
    self.musicPlayer = [MPMusicPlayerController iPodMusicPlayer];

    [marr addObject: [self.songList objectAtIndex:songnum]];
    
    
    [ self.musicPlayer setQueueWithItemCollection:queue];
    
    MPMediaItemArtwork *artwork = [[self.songList objectAtIndex:songnum] valueForProperty: MPMediaItemPropertyArtwork];
    UIImage *artworkImage = nil;
    if (artwork)
    {
        artworkImage = [artwork imageWithSize: CGSizeMake (150,150)];
    }
  
    
    self.imvAlbumCover.image=[self maketImageBlacknWhite:artworkImage];


    NSLog(@"%@",[[self.songList objectAtIndex:songnum] valueForProperty: MPMediaItemPropertyPlaybackDuration]);
    
    lblTimeRemains.text=[NSString stringWithFormat:@"%@",[[self.songList objectAtIndex:songnum] valueForProperty: MPMediaItemPropertyPlaybackDuration]];
    int ss=0,mm=0;

    ss=[lblTimeRemains.text intValue] % 60;
    mm=[lblTimeRemains.text intValue]/ 60;
    lblTimeRemains.text=[NSString stringWithFormat:@"%d:%d",mm,ss];
    tottime=[[[self.songList objectAtIndex:songnum] valueForProperty: MPMediaItemPropertyPlaybackDuration] intValue];
    if ([marr count] == 0)
        NSLog(@"No self.songList that short!");
    else
        queue = [MPMediaItemCollection collectionWithItems:marr];
    if (queue)
    {
        [self.musicPlayer setQueueWithItemCollection:queue];
        [self.musicPlayer play];

        
    }
}
-(void)updatetime
{

    NSNumber *duration = [self.musicPlayer.nowPlayingItem valueForProperty:MPMediaItemPropertyPlaybackDuration];
    
    float totalTime = [duration floatValue];
    
    
    int ss=0,mm=0;
    ss=(int)self.musicPlayer.currentPlaybackTime % 60;
    mm=(int)self.musicPlayer.currentPlaybackTime / 60;

    lblTimeElapsed.text=[NSString stringWithFormat:@"%d:%d",mm,ss];


    [sliderPlayTime setProgress:(self.musicPlayer.currentPlaybackTime/totalTime)];
 
    ss=((int)totalTime-(int)self.musicPlayer.currentPlaybackTime) % 60;
    mm=(totalTime-(int)self.musicPlayer.currentPlaybackTime) / 60;
    
    lblTimeRemains.text=[NSString stringWithFormat:@"- %d:%d",mm,ss];

}
-(IBAction)next:(id)sender
{
        [self playsong:++self.songNumber];
    
}
-(IBAction)prev:(id)sender
{
    [self playsong:--self.songNumber];

    
}
-(IBAction)play1:(id)sender
{
    if (self.musicPlayer.playbackState==MPMoviePlaybackStatePlaying)
    {
        [self.musicPlayer pause];
        [btnPlay setImage:[UIImage imageNamed:@"Pause.png"] forState:UIControlStateNormal];
        [NSTimer scheduledTimerWithTimeInterval:1.0/60.0 target:self selector:@selector(updatetime) userInfo:nil repeats:YES];
    }
    else
    {
        [self.musicPlayer play];
        [btnPlay setImage:[UIImage imageNamed:@"Play.png"] forState:UIControlStateNormal];
       [NSTimer cancelPreviousPerformRequestsWithTarget:self];
        
    }
}
- (void) registerMediaPlayerNotifications
{
    NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
    [notificationCenter addObserver: self
                           selector: @selector (handle_NowPlayingItemChanged:)
                               name: MPMusicPlayerControllerNowPlayingItemDidChangeNotification
                             object: musicPlayer];
    [notificationCenter addObserver: self
                           selector: @selector (handle_PlaybackStateChanged:)
                               name: MPMusicPlayerControllerPlaybackStateDidChangeNotification
                             object: musicPlayer];
    [notificationCenter addObserver: self
                           selector: @selector (handle_VolumeChanged:)
                               name: MPMusicPlayerControllerVolumeDidChangeNotification
                             object: musicPlayer];
    [musicPlayer beginGeneratingPlaybackNotifications];
}

- (void) handle_VolumeChanged: (id) notification
{
    MPMusicPlaybackState playbackState = [musicPlayer playbackState];
    if (playbackState == MPMusicPlaybackStatePaused) {
        [btnPlay setImage:[UIImage imageNamed:@"Play.png"] forState:UIControlStateNormal];
    } else if (playbackState == MPMusicPlaybackStatePlaying)
    {
        [btnPlay setImage:[UIImage imageNamed:@"Pause.png"] forState:UIControlStateNormal];
    } else if (playbackState == MPMusicPlaybackStateStopped)
    {
        [btnPlay setImage:[UIImage imageNamed:@"Play.png"] forState:UIControlStateNormal];
        //[musicPlayer stop];
    }
}
- (void) handle_PlaybackStateChanged: (id) notification
{
    MPMusicPlaybackState playbackState = [musicPlayer playbackState];
    if (playbackState == MPMusicPlaybackStatePaused) {
        [btnPlay setImage:[UIImage imageNamed:@"Play.png"] forState:UIControlStateNormal];
    } else if (playbackState == MPMusicPlaybackStatePlaying)
    {
        [btnPlay setImage:[UIImage imageNamed:@"Pause.png"] forState:UIControlStateNormal];
    } else if (playbackState == MPMusicPlaybackStateStopped)
    {
        [btnPlay setImage:[UIImage imageNamed:@"Play.png"] forState:UIControlStateNormal];
        [musicPlayer stop];
    }
}

- (void) handle_NowPlayingItemChanged: (id) notification
{
    MPMediaItem *currentItem = [musicPlayer nowPlayingItem];
    UIImage *artworkImage = [UIImage imageNamed:@"noArtworkImage.png"];
    MPMediaItemArtwork *artwork = [currentItem valueForProperty: MPMediaItemPropertyArtwork];
    if (artwork)
    {
        artworkImage = [artwork imageWithSize: CGSizeMake (200, 200)];
    }
    self.imvAlbumCover.image=[self maketImageBlacknWhite:artworkImage];
    NSString *titleString = [currentItem valueForProperty:MPMediaItemPropertyTitle];
    if (titleString)
    {
        self.lblSongName.text = [NSString stringWithFormat:@"Title: %@",titleString];
    }
    else
    {
        self.lblSongName.text = @"Title: Unknown title";
    }
   
    NSString *albumString = [currentItem valueForProperty:MPMediaItemPropertyAlbumTitle];
    if (albumString)
    {
        self.lblAlbumName.text = [NSString stringWithFormat:@"Album: %@",albumString];
    }
    else
    {
        self.lblAlbumName.text = @"Album: Unknown album";
    }
}

-(IBAction)selectTab:(UIButton *)btn
{
    switch (btn.tag)
    {
        case 101: {
                    app.window.rootViewController=app.navHomeView;
                    break;
                   }
        case 102: {
                    app.window.rootViewController=app.navPlayListView;
                    break;
                  }
        case 103:
                {
                    app.window.rootViewController=app.navSongsView;
                    break;
                }
        case 104:
                {
                    app.window.rootViewController=app.navAlbumsView;
                    break;
                }
            
        case 105:
                {
                    app.window.rootViewController=app.navMoreView;
                    break;
                }
            
            
        default:
            break;
    }
}

-(UIImage *) maketImageBlacknWhite:(UIImage *)img
{
    UIImage *originalImage = img;
    
    CGColorSpaceRef colorSapce = CGColorSpaceCreateDeviceGray();
    CGContextRef context = CGBitmapContextCreate(nil, originalImage.size.width, originalImage.size.height, 8, originalImage.size.width, colorSapce, kCGImageAlphaNone);
    CGContextSetInterpolationQuality(context, kCGInterpolationHigh);
    CGContextSetShouldAntialias(context, NO);
    CGContextDrawImage(context, CGRectMake(0, 0, originalImage.size.width, originalImage.size.height), [originalImage CGImage]);
    
    CGImageRef bwImage = CGBitmapContextCreateImage(context);
    CGContextRelease(context);
    CGColorSpaceRelease(colorSapce);
    
    UIImage *resultImage = [UIImage imageWithCGImage:bwImage]; // This is result B/W image.
    CGImageRelease(bwImage);
    return  resultImage;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
