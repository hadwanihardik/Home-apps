//
//  MoreView.h
//  MyMusicPlayer
//
//  Created by Hardik Hadwani on 08/12/13.
//  Copyright (c) 2013 Hardik Hadwani. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MoreView : UIViewController

@end
