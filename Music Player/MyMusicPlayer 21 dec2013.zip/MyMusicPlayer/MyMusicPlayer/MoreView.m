//
//  MoreView.m
//  MyMusicPlayer
//
//  Created by Hardik Hadwani on 08/12/13.
//  Copyright (c) 2013 Hardik Hadwani. All rights reserved.
//

#import "MoreView.h"
#import "AppDelegate.h"

@interface MoreView ()

@end

@implementation MoreView

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
-(IBAction)selectTab:(UIButton *)btn
{
    AppDelegate *app=(AppDelegate *)[[UIApplication sharedApplication] delegate];
    switch (btn.tag)
    {
        case 101: {
            app.window.rootViewController=app.navHomeView;
            break;
        }
        case 102: {
            app.window.rootViewController=app.navPlayListView;
            break;
        }
        case 103:
        {
            app.window.rootViewController=app.navSongsView;
            break;
        }
        case 104:
        {
            app.window.rootViewController=app.navAlbumsView;
            break;
        }
            
        case 105:
        {
            app.window.rootViewController=app.navMoreView;
            break;
        }
            
            
        default:
            break;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
