//
//  AlbumsView.h
//  MyMusicPlayer
//
//  Created by Hardik Hadwani on 08/12/13.
//  Copyright (c) 2013 Hardik Hadwani. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MPMediaItemCollection.h>
#import <MediaPlayer/MPMusicPlayerController.h>

@interface AlbumsView : UIViewController

{
    IBOutlet UITableView *tblSongs;
    
}
@property (nonatomic,retain)   NSMutableArray *songList;

@end
