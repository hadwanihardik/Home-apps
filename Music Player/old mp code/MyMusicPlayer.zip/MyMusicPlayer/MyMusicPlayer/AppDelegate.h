//
//  AppDelegate.h
//  MyMusicPlayer
//
//  Created by Hardik Hadwani on 07/12/13.
//  Copyright (c) 2013 Hardik Hadwani. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MPMediaItemCollection.h>
#import <MediaPlayer/MPMusicPlayerController.h>
#import "HomePage.h"
#import "SongesView.h"
#import "AlbumsView.h"
#import "PlayListView.h"
#import "MoreView.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>
{

}
@property (strong, nonatomic) UIWindow *window;
@property(nonatomic,retain)  UINavigationController *navHomeView;
@property(nonatomic,retain)  UINavigationController *navPlayListView;
@property(nonatomic,retain)  UINavigationController *navSongsView;
@property(nonatomic,retain)  UINavigationController *navAlbumsView;
@property(nonatomic,retain)  UINavigationController *navMoreView;
@property (nonatomic,retain)   NSMutableArray *songList;
@property (nonatomic,retain) HomePage *home;
-(void) showhomepage;

@end
