//
//  AppDelegate.m
//  MyMusicPlayer
//
//  Created by Hardik Hadwani on 07/12/13.
//  Copyright (c) 2013 Hardik Hadwani. All rights reserved.
//

#import "AppDelegate.h"
#import "HomePage.h"
#import "SongesView.h"
#import "AlbumsView.h"
#import "PlayListView.h"
#import "MoreView.h"
#import <MediaPlayer/MediaPlayer.h>
#import <MediaPlayer/MPMediaItemCollection.h>

@implementation AppDelegate
@synthesize navHomeView,navAlbumsView,navPlayListView,navMoreView,navSongsView,songList;
@synthesize home;
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    
    self.home=[[HomePage alloc] initWithNibName:@"HomePage" bundle:Nil];
    navHomeView=[[UINavigationController alloc] initWithRootViewController:self.home];
    self.navHomeView.navigationBar.hidden=TRUE;

    PlayListView *playlist=[[PlayListView alloc] initWithNibName:@"PlayListView" bundle:Nil];
    self.navPlayListView=[[UINavigationController alloc] initWithRootViewController:playlist];
    self.navPlayListView.navigationBar.hidden=TRUE;

    SongesView *songs=[[SongesView alloc] initWithNibName:@"SongesView" bundle:Nil];
    self.navSongsView=[[UINavigationController alloc] initWithRootViewController:songs];
    self.navSongsView.navigationBar.hidden=TRUE;

    AlbumsView *albums=[[AlbumsView alloc] initWithNibName:@"AlbumsView" bundle:Nil];
    self.navAlbumsView=[[UINavigationController alloc] initWithRootViewController:albums];
    navAlbumsView.navigationBar.hidden=TRUE;
    
    MoreView *more=[[MoreView alloc] initWithNibName:@"MoreView" bundle:Nil];
    self. navMoreView=[[UINavigationController alloc] initWithRootViewController:more];
    self.navMoreView.navigationBar.hidden=TRUE;


    MPMediaQuery* query = [MPMediaQuery songsQuery];
    self.songList=[[NSMutableArray alloc] init];
    
    
    self.songList=[[NSMutableArray alloc] init];
       // prove we've performed the query, by logging the album titles
    for (MPMediaItem* song in query.items)
    {
        [self.songList addObject: song];
    }
   // NSLog(@"%@",self.songList);
    songs.songList=self.songList;
    self.home.songList=self.songList;
    query = [MPMediaQuery albumsQuery];
    // prove we've performed the query, by logging the album titles
    MPMediaQuery *albumsQuery = [MPMediaQuery albumsQuery];
  
    NSArray *album = [albumsQuery collections];
    for (MPMediaItemCollection *albumCollection in album)
    {
        NSString *albumTitle = [[albumCollection representativeItem] valueForProperty:MPMediaItemPropertyAlbumTitle];
        NSLog(@"%@",albumTitle);
    }
    

    self.home.songNumber=0;
    albums.songList=[album mutableCopy];
    [self.window makeKeyAndVisible];
    [self showhomepage];
    return YES;
}
-(void) showhomepage
{
    self.window.rootViewController=self.navHomeView;

}
- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    [self.home.musicPlayer pause];
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
