//
//  HomePage.h
//  MyMusicPlayer
//
//  Created by Hardik Hadwani on 07/12/13.
//  Copyright (c) 2013 Hardik Hadwani. All rights reserved.
//

#import <UIKit/UIKit.h>
#include <AudioToolbox/AudioToolbox.h>
#import <AVFoundation/AVFoundation.h>
#import <MediaPlayer/MediaPlayer.h>

@interface HomePage : UIViewController<AVAudioPlayerDelegate,MPMediaPickerControllerDelegate>
{

    MPMusicPlayerController		*musicPlayer;
	MPMediaItemCollection		*userMediaItemCollection;
    IBOutlet UIImageView *imvAlbumCover;
    IBOutlet UILabel *lblSongName;
    IBOutlet UILabel *lblAlbumName;
    IBOutlet UILabel *lblTimeElapsed;
    IBOutlet UILabel *lblTimeRemains;

    int n;
    bool play;
    IBOutlet UIButton *btnPlay;
    IBOutlet UIProgressView *sliderPlayTime;
    int tottime;


    
}

-(IBAction)selectTab:(UIButton *)btn;
@property (nonatomic,retain)   NSMutableArray *songList;
@property (nonatomic,retain) MPMusicPlayerController *musicPlayer;
@property (nonatomic,retain)IBOutlet UIImageView *imvAlbumCover;
@property (nonatomic,retain)IBOutlet UILabel *lblSongName;
@property (nonatomic,retain)IBOutlet UILabel *lblAlbumName;
@property (nonatomic)int songNumber;
-(void)playsong:(int )songnum;

@end
