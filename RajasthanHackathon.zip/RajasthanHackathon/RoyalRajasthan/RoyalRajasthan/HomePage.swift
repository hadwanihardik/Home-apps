//
//  HomePage.swift
//  RoyalRajasthan
//
//  Created by Hardik on 12/2/17.
//  Copyright © 2017 Hardik. All rights reserved.
//

import UIKit

class HomePage: UIViewController,UITableViewDataSource,UITableViewDelegate {

    @IBOutlet weak var tblPlaces: UITableView!
    @IBOutlet weak var menuView: UIView!
    @IBOutlet weak var btnMenu1: UIButton!
    @IBOutlet weak var btnMenu3: UIButton!
    @IBOutlet weak var btnMenu2: UIButton!
    @IBOutlet weak var btnMenu: UIButton!
    @IBOutlet weak var leadingConstraint: NSLayoutConstraint!
    var arrayPlaces =  [String:String]();
    var isMenuOpen =  false;

    override func viewDidLoad() {
        super.viewDidLoad()
        tblPlaces.register(UINib(nibName: "PlaceCell", bundle: nil), forCellReuseIdentifier: "PlaceCell")

        // Do any additional setup after loading the view.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10//arrayPlaces.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let identifier = "PlaceCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: identifier) as! PlaceCell
        cell.imvPlace.image = UIImage(named: "JAIPUR")
        cell.lblPlaceName.text = "JAIPUR"
        cell.lblTagLine.text = "Pink City"
        return cell;

    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    @IBAction func openCloseMenu(_ sender: Any) {
        if(isMenuOpen == false)
        {
            leadingConstraint.constant = 0
            UIView.animate(withDuration: 0.5, animations: {
                self.view.layoutIfNeeded()
            }, completion:
                {
                    (value: Bool) in
//                    self.leadingConstraint.constant = 0
//                    UIView.animate(withDuration: 0.5, animations: {
//                        self.view.layoutIfNeeded()
//                    }, completion:
//                        {
//                            (value: Bool) in
//                            self.btn3Leading.constant = 0
//                            UIView.animate(withDuration: 0.5) {
//                                self.view.layoutIfNeeded()
//                            }
//                    })
            })
            isMenuOpen = true
        }
        else
        {
            leadingConstraint.constant = -240
            
            UIView.animate(withDuration: 0.5, animations: {
                self.view.layoutIfNeeded()
            }, completion:
                {
                    (value: Bool) in
//                    self.btn2Leading.constant = -190
//                    UIView.animate(withDuration: 0.5, animations: {
//                        self.view.layoutIfNeeded()
//                    }, completion:
//                        {
//                            (value: Bool) in
//                            self.btn3Leading.constant = -190
//                            UIView.animate(withDuration: 0.5) {
//                                self.view.layoutIfNeeded()
//                            }
//                            
//                    })
                    
            })
            isMenuOpen = false

        }
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
